// Empty JS for your own code to be here
/* function insertInfo() {
  var table = document.getElementById("myTable");
  var row = table.insertRow(0);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  cell1.innerHTML = "Student";
  cell2.innerHTML = "Khanh Lam Quoc";
}

window.onload = insertInfo;
*/